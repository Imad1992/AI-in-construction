"""Reproducible fictional construction jobs; never real company records."""
import numpy as np
import pandas as pd
from config import DATA

def generate(n=600, seed=42):
    rng = np.random.default_rng(seed)
    types = rng.choice(['Commercial','Residential','Healthcare','Education','Industrial'],n)
    area = rng.uniform(150,15000,n).round(1)
    complexity = rng.integers(1,6,n)
    duration = np.maximum(2,area/950 + complexity*1.7 + rng.normal(0,2,n)).round(1)
    labour = np.maximum(100,area*(1.1 + .25*complexity) + duration*40 + rng.normal(0,450,n)).round()
    material = np.maximum(50,area*(.65 + .18*complexity) + rng.normal(0,300,n)).round()
    labour_rate = rng.uniform(24,39,n)
    material_rate = rng.uniform(32,65,n)
    actual_cost = (labour*labour_rate + material*material_rate).round(2)
    budget = (actual_cost*rng.uniform(.85,1.20,n)).round(2)
    start = pd.Timestamp('2022-01-01') + pd.to_timedelta(rng.integers(0,1500,n),unit='D')
    df = pd.DataFrame({'job_id':[f'JOB-{i:05}' for i in range(1,n+1)],'project_type':types,'area_sqm':area,'complexity':complexity,'duration_weeks':duration,'start_date':start.strftime('%Y-%m-%d'),'labour_hours':labour,'material_units':material,'labour_rate':labour_rate.round(2),'material_rate':material_rate.round(2),'actual_cost':actual_cost,'budget':budget})
    DATA.mkdir(exist_ok=True,parents=True)
    df.to_csv(DATA/'jobs.csv',index=False)
    return df

if __name__=='__main__':
    print(f'Generated {len(generate())} fictional jobs')
