"""Leakage-aware regression evaluation with chronological holdout."""
import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
from sklearn.multioutput import MultiOutputRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from config import MODEL
from src.pipeline import read_jobs
FEATURES=['project_type','area_sqm','complexity','duration_weeks']
TARGETS=['labour_hours','material_units']

def train():
    df=read_jobs().sort_values('start_date').reset_index(drop=True)
    cutoff=int(len(df)*.8)
    if cutoff<10 or cutoff==len(df): raise ValueError('Not enough training data')
    pre=ColumnTransformer([('category',Pipeline([('impute',SimpleImputer(strategy='most_frequent')),('encode',OneHotEncoder(handle_unknown='ignore'))]),['project_type']),('numeric',SimpleImputer(strategy='median'),['area_sqm','complexity','duration_weeks'])])
    pipe=Pipeline([('preprocess',pre),('model',MultiOutputRegressor(RandomForestRegressor(n_estimators=120,min_samples_leaf=3,random_state=42,n_jobs=-1)))])
    train_df,test_df=df.iloc[:cutoff],df.iloc[cutoff:]
    pipe.fit(train_df[FEATURES],train_df[TARGETS])
    pred=pipe.predict(test_df[FEATURES]); truth=test_df[TARGETS].to_numpy()
    metrics={name:{'MAE':round(float(mean_absolute_error(truth[:,i],pred[:,i])),2),'RMSE':round(float(np.sqrt(mean_squared_error(truth[:,i],pred[:,i]))),2),'R2':round(float(r2_score(truth[:,i],pred[:,i])),3)} for i,name in enumerate(TARGETS)}
    MODEL.parent.mkdir(exist_ok=True,parents=True)
    joblib.dump({'pipeline':pipe,'metrics':metrics,'features':FEATURES,'training_rows':len(train_df),'test_rows':len(test_df)},MODEL)
    return metrics

def estimate(project_type,area_sqm,complexity,duration_weeks,labour_rate=30,material_rate=45):
    artifact=joblib.load(MODEL)
    row=pd.DataFrame([{'project_type':project_type,'area_sqm':area_sqm,'complexity':complexity,'duration_weeks':duration_weeks}])
    labour,material=artifact['pipeline'].predict(row)[0]
    return {'labour_hours':round(max(0,float(labour)),1),'material_units':round(max(0,float(material)),1),'estimated_cost':round(max(0,float(labour))*labour_rate+max(0,float(material))*material_rate,2)}

if __name__=='__main__': print(train())
