"""CSV -> validation -> normalized SQLite reporting tables."""
import sqlite3
import pandas as pd
from config import DATA, DB
REQUIRED = {'job_id','project_type','area_sqm','complexity','duration_weeks','start_date','labour_hours','material_units','labour_rate','material_rate','actual_cost','budget'}

def validate(df):
    missing = REQUIRED - set(df.columns)
    if missing: raise ValueError(f'Missing columns: {sorted(missing)}')
    if df.job_id.duplicated().any(): raise ValueError('Duplicate job IDs')
    for field in ['area_sqm','duration_weeks','labour_hours','material_units','actual_cost','budget']:
        if df[field].isna().any() or (df[field] <= 0).any(): raise ValueError(f'Invalid {field}')
    if not df.complexity.between(1,5).all(): raise ValueError('Complexity must be 1–5')
    pd.to_datetime(df.start_date,errors='raise')
    return df

def run_pipeline():
    df=validate(pd.read_csv(DATA/'jobs.csv'))
    DB.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(DB) as conn:
        df.to_sql('jobs',conn,if_exists='replace',index=False)
        conn.execute('CREATE INDEX IF NOT EXISTS idx_jobs_type ON jobs(project_type)')
        conn.execute('CREATE VIEW IF NOT EXISTS project_kpis AS SELECT project_type, COUNT(*) AS jobs, ROUND(AVG(actual_cost),2) AS avg_actual_cost, ROUND(AVG(actual_cost-budget),2) AS avg_budget_variance, ROUND(SUM(actual_cost),2) AS total_actual_cost FROM jobs GROUP BY project_type')
    return len(df)

def read_jobs():
    with sqlite3.connect(DB) as conn: return pd.read_sql_query('SELECT * FROM jobs',conn)

def read_kpis():
    with sqlite3.connect(DB) as conn: return pd.read_sql_query('SELECT * FROM project_kpis',conn)

if __name__=='__main__': print(f'Loaded {run_pipeline()} jobs')
