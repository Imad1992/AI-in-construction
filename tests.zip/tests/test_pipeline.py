import pandas as pd
import pytest
from src.generate_data import generate
from src.pipeline import validate

def test_generated_data(tmp_path,monkeypatch):
    import src.generate_data as g
    monkeypatch.setattr(g,'DATA',tmp_path)
    df=generate(25)
    assert len(validate(df))==25
    assert (df.actual_cost>0).all()

def test_duplicate_ids_rejected(tmp_path,monkeypatch):
    import src.generate_data as g
    monkeypatch.setattr(g,'DATA',tmp_path)
    df=generate(10)
    df.loc[1,'job_id']=df.loc[0,'job_id']
    with pytest.raises(ValueError,match='Duplicate'): validate(df)
