from src.generate_data import generate
from src.pipeline import run_pipeline
from src.model import train

def main():
    print('Generating synthetic dataset...')
    print(f'Generated {len(generate())} jobs')
    print(f'Loaded {run_pipeline()} jobs into SQLite')
    print('Model metrics:',train())
if __name__=='__main__':main()
